@echo off
REM ComicCraft launcher for Windows - double-click this file.
cd /d "%~dp0"

REM "python --version" (not "where python") so the Microsoft Store placeholder isn't mistaken for Python
python --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.10+ from https://www.python.org/downloads/
    echo and tick "Add Python to PATH" during installation.
    pause
    exit /b 1
)
python -c "import sys; sys.exit(sys.version_info < (3, 10))"
if errorlevel 1 (
    echo Your Python is too old. Install Python 3.10 or newer from https://www.python.org/downloads/
    pause
    exit /b 1
)

if not exist .venv (
    echo Creating virtual environment...
    python -m venv .venv || (pause & exit /b 1)
)
call .venv\Scripts\activate.bat

echo Installing / checking requirements...
python -m pip install --disable-pip-version-check -q -r requirements.txt || (pause & exit /b 1)

if not exist .env python -m app.setup_keys
if not exist .env (
    echo No .env file was saved. Run this file again to enter your API keys.
    pause
    exit /b 1
)

echo.
echo ComicCraft is starting at http://127.0.0.1:8000  (press Ctrl+C to stop)
start "" cmd /c "timeout /t 4 >nul & start http://127.0.0.1:8000"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
