#!/usr/bin/env bash
# ComicCraft launcher for macOS / Linux:  ./run.sh
set -e
cd "$(dirname "$0")"

PY=$(command -v python3 || command -v python || true)
if [ -z "$PY" ]; then
  echo "Python was not found. Install Python 3.10+ from https://www.python.org/downloads/"
  exit 1
fi

if [ ! -d .venv ]; then
  echo "Creating virtual environment..."
  "$PY" -m venv .venv
fi
source .venv/bin/activate

echo "Installing / checking requirements..."
python -m pip install --disable-pip-version-check -q -r requirements.txt

if [ ! -f .env ]; then
  python -m app.setup_keys
fi

echo
echo "ComicCraft is starting at http://127.0.0.1:8000  (press Ctrl+C to stop)"
( sleep 4; (open http://127.0.0.1:8000 || xdg-open http://127.0.0.1:8000) >/dev/null 2>&1 ) &
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
